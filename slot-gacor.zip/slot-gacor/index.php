<?php

function feedback404()
{
    header("HTTP/1.0 404 Not Found");
    echo "<h1><a href='https://tipsy77maxwin.com' class=btn1>KLIK SINI LINK DAFTAR</a></h1>";
}

if (isset($_GET['situsgacor'])) {
    $filename = "list.txt";
    $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $target_string = strtolower($_GET['situsgacor']);
    foreach ($lines as $item) {
        if (strtolower($item) === $target_string) {
            $BRAND = strtoupper($target_string);
        }
    }
    if (isset($BRAND)) {
        $BRANDS = $BRAND;
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $fullUrl = $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        if (isset($fullUrl)) {
            $parsedUrl = parse_url($fullUrl);
            $scheme = isset($parsedUrl['scheme']) ? $parsedUrl['scheme'] : '';
            $host = isset($parsedUrl['host']) ? $parsedUrl['host'] : '';
            $path = isset($parsedUrl['path']) ? $parsedUrl['path'] : '';
            $query = isset($parsedUrl['query']) ? $parsedUrl['query'] : '';
            $baseUrl = $scheme . "://" . $host . $path . '?' . $query;
            $urlPath = $baseUrl;
        } else {
            echo "URL saat ini tidak didefinisikan.";
        }
    } else {
        feedback404();
        exit();
    }
} else {
    feedback404();
    exit();
}
date_default_timezone_set('Asia/Jakarta');
$currentTime = date('Y-m-d\TH:i:sP');

?>


<!--EDIT/UBAH SCRIPT AMP & BUTTON-->

<!DOCTYPE html>
<html amp lang="id">
<head>
<meta charset="utf-8">
<meta name="format-detection" content="telephone=no">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" href="image/banner.png" as="image">
<title><?php echo $BRANDS ?>: Link Alternatif Login <?php echo $BRANDS ?> Situs Slot Gacor Server Thailand Winrate Tertinggi Hari Ini Zeus</title>
<meta name="description" content="<?php echo $BRANDS ?> adalah salah satu situs judi slot online gacor terpercaya indonesia. Daftar <?php echo $BRANDS ?> sekarang melalui link alternatifnya di <?php echo $BRANDS ?> Terbaru."/>
<meta name="keywords" content="<?php echo $BRANDS ?>, <?php echo $BRANDS ?>, link <?php echo $BRANDS ?>, link <?php echo $BRANDS ?>, slot <?php echo $BRANDS ?>, <?php echo $BRANDS ?> <?php echo $BRANDS ?>, daftar <?php echo $BRANDS ?>, login <?php echo $BRANDS ?>, rtp gacor <?php echo $BRANDS ?>"/>
<meta name="robots" content="index, follow"/>
<meta name="theme-color" content="#0a0a0a"/>
<meta content="true" name="HandheldFriendly">
<meta content="width" name="MobileOptimized">
<meta name="apple-mobile-web-app-status-bar-style" content="default"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="mobile-web-app-capable" content="yes"/>
<meta name="language" content="ID">
<meta name="copyright" content="<?php echo $BRANDS ?>">
<meta name="author" content="<?php echo $BRANDS ?>">
<meta name="distribution" content="global">
<meta name="publisher" content="<?php echo $BRANDS ?>">
<meta name="geo.placename" content="DKI Jakarta">
<meta name="geo.country" content="ID">
<meta name="geo.region" content="ID"/>
<meta name="tgn.nation" content="Indonesia">
<link rel="canonical" href="<?php echo $urlPath ?>">
<!-- OG:FACEBOOK -->
<meta property="og:locale" content="id_ID"/>
<meta property="og:type" content="website"/>
<meta property="og:title" content="<?php echo $BRANDS ?>: Link Alternatif Login <?php echo $BRANDS ?> Situs Slot Gacor Server Thailand Winrate Tertinggi Hari Ini Zeus"/>
<meta property="og:description" content="<?php echo $BRANDS ?> adalah salah satu situs judi slot online gacor terpercaya indonesia. Daftar <?php echo $BRANDS ?> sekarang melalui link alternatifnya di <?php echo $BRANDS ?> Terbaru."/>
<meta property="og:url" content="<?php echo $urlPath ?>"/>
<meta property="og:site_name" content="<?php echo $BRANDS ?>"/>
<meta property="og:image" content="image/banner.png"/>
<meta property="og:image:type" content="image/banner.png"/>
<!-- OG:TWITTER -->
<meta name="twitter:card" content="summary"/>
<meta name="twitter:image" content="image/banner.png"/>
<meta name="twitter:site" content="@slotgacor"/>
<meta name="twitter:creator" content="@slotgacor"/>
<meta name="twitter:label1" content="Estimasi waktu membaca"/>
<meta name="twitter:data1" content="15 menit"/>
<link rel="preload" as="image" href="image/banner.png"/>
<link rel="preload" as="image" href="image/banner.png"/>
<link rel="preload" as="image" href="image/banner.png"/>
<meta name="supported-amp-formats" content="websites, stories, ads, email">
<link href="image/banner.png" rel="shortcut icon" type="image/x-icon"/>
<link rel="apple-touch-icon-precomposed" href="image/banner.png"/>
<link rel="preload" as="image" href="image/banner.png"/>
<link rel="preload" as="image" href="image/banner.png"/>
<link rel="preload" as="image" href="image/banner.png"/>
<meta name="supported-amp-formats" content="websites, stories, ads, email">
<link href="image/banner.png" rel="shortcut icon" type="image/x-icon"/>
<link rel="apple-touch-icon-precomposed" href="image/banner.png"/>
<script async src="https://cdn.ampproject.org/v0.js"></script>
<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;700&display=swap">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;700&display=swap" rel="stylesheet">
<link rel="shortcut icon" href="image/icon.webp" type="image/x-icon">
<title><?php echo $BRANDS ?>: Link Alternatif Login Situs Slot Gacor Server Thailand Winrate Tertinggi Hari Ini Zeus</title>
<meta name="title" content="<?php echo $BRANDS ?>: Link Alternatif Login  Situs Slot Gacor Server Thailand Winrate Tertinggi Hari Ini Zeus">
<meta name="description" content="<?php echo $BRANDS ?> merupakan situs penyedia rtp fresh tergacor di link login alternatif <?php echo $BRANDS ?>">
<style amp-custom>
*{box-sizing:border-box;margin:0;padding:0}:focus{outline:0}::-webkit-scrollbar{display:none}a,a:after,a:hover,a:visited{text-decoration:none;color:#000 }
html{max-width:500px;margin:0 auto;background:linear-gradient(176deg,#0a0a0a 0,#0f0b10 50%);}body{color:#bdc1c6;font-family:'Noto Sans',arial,sans-serif}
.atas{display:grid;min-height:100vh}.atasbox{margin:auto;text-align:center}.ataslink{display:inline-grid;margin:.88rem 0}
.ataslink a{padding:.5rem 3.8rem;background:linear-gradient(to bottom,#fff 0,#80878b 100%);margin-bottom:.5rem;border-radius:.38rem;box-shadow:0 -1px #ccb38a88;letter-spacing:1px}
.ataslink a.btn1{color:#020202;background:linear-gradient(to bottom, #ebcb80 0%, #eacb80 100%);box-shadow:none;font-weight:bold}
.imghero{box-shadow:inset 0 0 0 8px #888;border-radius:8px}
</style>
</head>
<body>
<main>
<div class=atas>
  <div class=atasbox>
    <div><amp-img class=imghero height=300 width=300 alt="<?php echo $BRANDS ?>" src="https://i.ibb.co/5xkbr4K/666.png"></amp-img></div>
    <div class=ataslink>
      <a href='https://tipsy77maxwin.com' class=btn1>MASUK <?php echo $BRANDS ?></a>
      <a href='https://tipsy77maxwin.com' target=_blank rel="noopener noreferrer nofollow">LIVECHAT <?php echo $BRANDS ?></a>
      <a href='https://tipsy77maxwin.com' target=_blank rel="noopener noreferrer nofollow">APLIKASI <?php echo $BRANDS ?></a>
      <a href='https://tipsy77maxwin.com' target=_blank rel="noopener noreferrer nofollow">WHATSAPP <?php echo $BRANDS ?></a>
      <a href='https://tipsy77maxwin.com' target=_blank rel="noopener noreferrer nofollow">DAFTAR <?php echo $BRANDS ?></a>
    </div>
  </div>
</div>
</main>
</body>
</html>